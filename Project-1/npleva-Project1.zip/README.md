This website is a profile that I have created with all of my contacts and 
skill in one location, as well as to have me resume accessable. I also have 
it linked on my resume for people who are looking at job applications.

Some features I have in this website are:
- A nav bar to take you to different tabs like my resume and the link for my LinkedIn
- Both lists and tables showing my skills and education info
- Pictures for what current projects I am working on
- Seperate resume page that displays the pdf
- Mostly built of flexboxes 